<?php
$connection=mysqli_connect('localhost','root','','shopdbs');
session_start();